#' PRINT Hello World in spanish
#'
#' Not need input parameter
#' @param Null
#' @return Null
#' @export
HolaMundo <-function(){
print("HOLA MUNDO")
  return()
}
